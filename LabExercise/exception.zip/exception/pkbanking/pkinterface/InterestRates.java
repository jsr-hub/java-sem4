package pkbanking.pkinterface;
public interface InterestRates
{
	double sbrate=0.04;
	double rdrate=0.06;
	double fdrate=0.0825;
}